// Copyright 2015 GameSparks Ltd 2015, Inc. All Rights Reserved.
#ifndef GSConfig_h__
#define GSConfig_h__

#pragma once
#endif // GSConfig_h__

