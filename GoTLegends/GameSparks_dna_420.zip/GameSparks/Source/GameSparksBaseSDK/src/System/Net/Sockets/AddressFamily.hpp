#ifndef _SYSTEM_NET_SOCKETS_ADDRESSFAMILY_HPP_
#define _SYSTEM_NET_SOCKETS_ADDRESSFAMILY_HPP_

namespace System { namespace Net { namespace Sockets {

    enum class AddressFamily
    {
        InterNetwork
    };

}}}

#endif /* _SYSTEM_NET_SOCKETS_ADDRESSFAMILY_HPP_ */
