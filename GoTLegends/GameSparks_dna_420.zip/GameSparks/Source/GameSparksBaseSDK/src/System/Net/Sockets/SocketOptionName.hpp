#ifndef _SYSTEM_NET_SOCKETS_SOCKETOPTIONNAME_HPP_
#define _SYSTEM_NET_SOCKETS_SOCKETOPTIONNAME_HPP_

namespace System { namespace Net { namespace Sockets {

    enum class SocketOptionName
    {
        KeepAlive
    };

}}}

#endif /* _SYSTEM_NET_SOCKETS_SOCKETOPTIONNAME_HPP_ */
