#ifndef _SYSTEM_IASYNCRESULT_HPP_
#define _SYSTEM_IASYNCRESULT_HPP_

namespace System {

    class IAsyncResult
    {
        public:
            virtual ~IAsyncResult(){}
        private:
    };

}

#endif /* _SYSTEM_IASYNCRESULT_HPP_ */
