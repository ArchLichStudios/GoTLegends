#pragma once

#define GS_USE_STD_FUNCTION 1
#define GS_COMPILER_HAS_NULLPTR_SUPPORT 1
#define __NUMBERFORMATTING__ //avoid clashed with CarbonCore.framework/Headers/NumberFormatting.h
