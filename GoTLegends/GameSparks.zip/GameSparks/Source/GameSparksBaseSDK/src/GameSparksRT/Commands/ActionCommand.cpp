
#include "./ActionCommand.hpp"

namespace GameSparks { namespace RT {

        void ActionCommand::Execute() {
            action();
        }
    }} /* namespace GameSparks.RT */

	