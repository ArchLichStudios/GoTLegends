// use this file on iOS and Mac

#include "./GameSparksAll.cpp"
