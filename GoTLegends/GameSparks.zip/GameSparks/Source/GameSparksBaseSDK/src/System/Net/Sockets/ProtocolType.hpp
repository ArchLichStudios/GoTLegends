#ifndef _SYSTEM_NET_SOCKETS_PROTOCOLTYPE_HPP_
#define _SYSTEM_NET_SOCKETS_PROTOCOLTYPE_HPP_

namespace System { namespace Net { namespace Sockets {

    enum class ProtocolType
    {
        Tcp,
        Udp
    };

}}}

#endif /* _SYSTEM_NET_SOCKETS_PROTOCOLTYPE_HPP_ */
