#ifndef _SYSTEM_NET_SOCKETS_SOCKETOPTIONLEVEL_HPP_
#define _SYSTEM_NET_SOCKETS_SOCKETOPTIONLEVEL_HPP_

namespace System { namespace Net { namespace Sockets {

    enum class SocketOptionLevel
    {
        Socket
    };

}}}

#endif /* _SYSTEM_NET_SOCKETS_SOCKETOPTIONLEVEL_HPP_ */
