/* auto generated header, do not modify. */

#ifndef _GS_VERSION_H_INCLUDED_
#define _GS_VERSION_H_INCLUDED_

#include <GameSparks/gsstl.h>

namespace GameSparks
{
	namespace
	{
		static gsstl::string GS_SDK_VERSION = "1.1.23.0";
	}
}

#endif /* _GS_VERSION_H_INCLUDED_ */

